<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home Page</title>
    <style>
		body{
			background: crimson;
			color: white;
			font: bold;
			margin: 20px;
		}
	</style>
</head>
<body>
    <h1>Welcome to the Home Page</h1>
    <?php echo "Hello"; ?>
    <p>This is the main landing page of the website.</p>
</body>
</html>
